// src/environments/environment.prod.ts
export const environment = {
  production: true,
  baseUrl: 'https://your-production-url.com/api'
};


//1st deployment
// // src/environments/environment.prod.ts
// export const environment = {
//   production: true,
//   apiUrl: '/api',
//   appName: 'PIP_Tracker',
//   enabledDebug:false
 
// };
