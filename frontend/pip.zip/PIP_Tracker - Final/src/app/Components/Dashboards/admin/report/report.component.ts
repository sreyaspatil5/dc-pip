import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeService } from '../../../../services/employee.service';

@Component({
  selector: 'app-report',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.css']
})
export class ReportComponent implements OnInit {
  report = {
    totalEmployees: 0,
    totalHRs: 0,
    totalManagers: 0,
    totalAdmins: 0,
    totalGeneralEmployees: 0,
    totalOthers: 0
  };

  currentDate = new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric'
  });

  constructor(private empService: EmployeeService) {}

  ngOnInit(): void {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('❌ Token not found');
      return;
    }

    this.empService.getAllEmployees(token).subscribe({
      next: (employees) => {
        this.report.totalEmployees = employees.length;
        this.report.totalHRs = employees.filter(emp => emp.role?.toUpperCase() === 'HR').length;
        this.report.totalManagers = employees.filter(emp => emp.role?.toUpperCase() === 'MANAGER').length;
        this.report.totalAdmins = employees.filter(emp => emp.role?.toUpperCase() === 'ADMIN').length;
        this.report.totalGeneralEmployees = employees.filter(emp => emp.role?.toUpperCase() === 'EMPLOYEE').length;

        const knownRoles = ['HR', 'MANAGER', 'ADMIN', 'EMPLOYEE'];
        this.report.totalOthers = employees.filter(emp => !knownRoles.includes(emp.role?.toUpperCase())).length;
      },
      error: (err) => console.error('❌ Failed to load employees', err)
    });
  }
}
