import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeService } from '../../../../services/employee.service';

@Component({
  selector: 'app-feedback-notes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './feedback-notes.component.html',
  styleUrls: ['./feedback-notes.component.css']
})
export class FeedbackNotesComponent implements OnInit {
  receivedFeedbacks: any[] = [];
  userId = localStorage.getItem('userId') || localStorage.getItem('employeeId');
  token = localStorage.getItem('token');
  private service = inject(EmployeeService);
  private router = inject(Router);

  ngOnInit(): void {
    if (!this.userId || !this.token) {
      console.warn('⚠️ userId or token missing. Redirecting to login.');
      this.router.navigate(['/login']);
      return;
    }

    this.service.getFeedbacksReceived(this.userId, this.token).subscribe({
      next: (res: any[]) => {
        console.log('✅ Feedback response:', res);
        // Filter out entries with missing comments
        this.receivedFeedbacks = Array.isArray(res)
          ? res.filter(fb => fb.comments?.trim())
          : [];
      },
      error: (err: any) => {
        console.error('❌ Error fetching feedbacks:', err);
      }
    });
  }
}
