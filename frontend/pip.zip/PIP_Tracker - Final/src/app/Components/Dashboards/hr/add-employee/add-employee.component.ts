import { Component, inject } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule,
  AbstractControl,
  ValidationErrors
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EmployeeService } from '../../../../services/employee.service';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipsModule, MatChipInputEvent } from '@angular/material/chips';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-add-employee',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatChipsModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule
  ],
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent {
  separatorKeysCodes: number[] = [ENTER, COMMA];
  selectedSkills: string[] = [];

  today: string = this.getTodayDate();

  private fb = inject(FormBuilder);
  private employeeService = inject(EmployeeService);

  employeeForm: FormGroup = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email]],
    role: ['MANAGER', Validators.required],
    department: ['', [Validators.required, Validators.minLength(2), this.alphaOnlyValidator]],
    designation: ['', [Validators.required, Validators.minLength(2)]],
    skills: [''], // Skills are managed via chips, no direct validator needed here.
    managerId: ['', [Validators.pattern(/^[\w\d-]{36}$/)]],
    joiningDate: [this.today, [Validators.required, this.pastOrTodayValidator]],
    status: ['ACTIVE', Validators.required]
  });

  // Getters for easy access to form controls in the template
  get nameControl(): AbstractControl { return this.employeeForm.get('name')!; }
  get emailControl(): AbstractControl { return this.employeeForm.get('email')!; }
  get departmentControl(): AbstractControl { return this.employeeForm.get('department')!; }
  get designationControl(): AbstractControl { return this.employeeForm.get('designation')!; }
  get skillsControl(): AbstractControl { return this.employeeForm.get('skills')!; }
  get joiningDateControl(): AbstractControl { return this.employeeForm.get('joiningDate')!; }

  alphaOnlyValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value || '';
    return /^[A-Za-z ]+$/.test(value) ? null : { alphaOnly: true };
  }

  // NOTE: This validator is now for the input field, not the chip list itself.
  skillsValidator(control: AbstractControl): ValidationErrors | null {
    const value = control.value || '';
    return /^[A-Za-z, ]*$/.test(value) ? null : { invalidSkills: true };
  }

  pastOrTodayValidator(control: AbstractControl): ValidationErrors | null {
    const inputDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return inputDate <= today ? null : { futureDate: true };
  }

  getTodayDate(): string {
    const today = new Date();
    return today.toISOString().split('T')[0];
  }

  addSkill(event: MatChipInputEvent): void {
    const input = event.chipInput;
    const value = event.value?.trim();
    if (value && !this.selectedSkills.includes(value)) {
      this.selectedSkills.push(value);
      this.updateSkillsControl();
    }
    if (input) {
      input.clear();
    }
  }

  removeSkill(skill: string): void {
    this.selectedSkills = this.selectedSkills.filter(s => s !== skill);
    this.updateSkillsControl();
  }

  updateSkillsControl(): void {
    const skillsString = this.selectedSkills.join(', ');
    this.employeeForm.get('skills')?.setValue(skillsString);
    this.employeeForm.get('skills')?.markAsTouched();
    this.employeeForm.get('skills')?.updateValueAndValidity();
  }

  onSubmit(): void {
    this.employeeForm.markAllAsTouched();
    if (!this.employeeForm.valid) {
      alert('❌ Please correct the form errors before submitting.');
      return;
    }

    const token = localStorage.getItem('token');
    if (!token) {
      alert('❌ Token not found! Please login again.');
      return;
    }

    const rawForm = this.employeeForm.value;
    const payload = {
      ...rawForm,
      joiningDate: new Date(rawForm.joiningDate).toISOString(),
    };

    if (!payload.managerId || payload.managerId.trim().length !== 36) {
      delete payload.managerId;
    }

    this.employeeService.addEmployee(payload, token).subscribe({
      next: () => {
        alert('✅ Employee added successfully!');
        this.employeeForm.reset();
        this.selectedSkills = [];
        this.employeeForm.patchValue({ role: 'MANAGER', status: 'ACTIVE', joiningDate: this.today });
      },
      error: (err) => {
        console.error('❌ Error while adding employee:', err);
        const errorMsg = err?.status === 403
          ? 'HR is not authorized to create this role.'
          : err?.status === 400
          ? err?.error
          : 'Failed to add employee. Please try again.';
        alert(errorMsg);
      }
    });
  }
}