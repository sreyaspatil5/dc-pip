import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { trigger, transition, animate, style } from '@angular/animations';
import { EmployeeService } from '../../services/employee.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  animations: [
    trigger('fadeOutUp', [
      transition(':leave', [
        animate('300ms ease', style({ opacity: 0, transform: 'translateY(-20px)' }))
      ])
    ])
  ]
})
export class LoginComponent {
  email = '';
  password = '';
  role = 'ADMIN';
  errorMessage = '';
  isLoading = false;
  showPassword = false;
  showToast = false;

  failedAttempts = 0;
  lockoutUntil: Date | null = null;

  constructor(
    private employeeService: EmployeeService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  hasLeadingOrTrailingSpace(value: string): boolean {
    return value !== value.trim();
  }

  hasAnySpace(value: string): boolean {
    return /\s/.test(value);
  }

  hasUppercase(value: string): boolean {
    return value !== value.toLowerCase();
  }

  isValidEmailFormat(value: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  }

  validateEmail(): void {
    const trimmedEmail = this.email.trim();

    if (this.hasLeadingOrTrailingSpace(this.email)) {
      this.errorMessage = 'Email must not have leading or trailing spaces.';
    } else if (this.hasAnySpace(this.email)) {
      this.errorMessage = 'Email must not contain spaces.';
    } else if (this.hasUppercase(this.email)) {
      this.errorMessage = 'Email must be in lowercase only.';
    } else if (!trimmedEmail) {
      this.errorMessage = 'Email is required.';
    } else if (!this.isValidEmailFormat(trimmedEmail)) {
      this.errorMessage = 'Please enter a valid email address.';
    } else {
      this.errorMessage = '';
    }
  }

  login(): void {
    this.validateEmail();

    const trimmedEmail = this.email.trim();
    const trimmedPassword = this.password.trim();

    if (this.lockoutUntil && new Date() < this.lockoutUntil) {
      this.errorMessage = 'Too many failed attempts. Please try again after 5 minutes.';
      this.toastr.error(this.errorMessage);
      return;
    }

    if (
      this.hasLeadingOrTrailingSpace(this.email) ||
      this.hasAnySpace(this.email) ||
      this.hasUppercase(this.email) ||
      !trimmedEmail ||
      !this.isValidEmailFormat(trimmedEmail) ||
      this.hasLeadingOrTrailingSpace(this.password) ||
      this.hasAnySpace(this.password) ||
      !trimmedPassword
    ) {
      this.errorMessage = 'Invalid input. Please fix the email and password.';
      this.toastr.error(this.errorMessage);
      return;
    }

    this.isLoading = true;

    this.employeeService.login(this.email, this.password, this.role).subscribe({
      next: (res: any) => {
        this.failedAttempts = 0;
        this.lockoutUntil = null;

        const employee = res.employee || res.user || res;
        const actualRole = employee?.role?.toUpperCase() || 'UNKNOWN';

        if (actualRole !== this.role) {
          this.errorMessage = `Role mismatch: You selected "${this.role}", but your account is assigned to "${actualRole}".`;
          this.toastr.error(this.errorMessage);
          this.isLoading = false;
          return;
        }

        localStorage.setItem('token', res.token || '');
        localStorage.setItem('userId', employee.id || '');
        localStorage.setItem('email', employee.email || '');
        localStorage.setItem('role', actualRole);
        localStorage.setItem('user', JSON.stringify(employee));

        this.toastr.success(`Welcome ${employee.name || employee.email}! 🎉`, 'Login Successful');
        this.showToast = true;

        switch (actualRole) {
          case 'ADMIN': this.router.navigate(['/admin']); break;
          case 'HR': this.router.navigate(['/hr']); break;
          case 'MANAGER': this.router.navigate(['/manager']); break;
          case 'EMPLOYEE': this.router.navigate(['/empdashboard']); break;
          default:
            this.errorMessage = 'Unknown role. Please contact the administrator.';
        }

        this.isLoading = false;
      },
      error: () => {
        this.failedAttempts++;
        if (this.failedAttempts >= 3) {
          this.lockoutUntil = new Date(Date.now() + 3 * 60 * 1000);
          this.errorMessage = 'Too many failed attempts. Login locked for 5 minutes.';
          this.toastr.error(this.errorMessage);
        } else {
          this.errorMessage = 'Login failed: Invalid credentials or unauthorized access.';
          this.toastr.error('Login failed. Please try again.');
        }
        this.isLoading = false;
      }
    });
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  navigateToForgotPassword(): void {
    this.router.navigate(['/forgot-password']);
  }

  navigatetoemp(): void {
    this.role = 'EMPLOYEE';
    this.errorMessage = '';
  }

  navigatetomanager(): void {
    this.role = 'MANAGER';
    this.errorMessage = '';
  }

  navigatetohr(): void {
    this.role = 'HR';
    this.errorMessage = '';
  }

  navigatetoadmin(): void {
    this.role = 'ADMIN';
    this.errorMessage = '';
  }

  onClose(): void {
    this.errorMessage = '';
  }
}
