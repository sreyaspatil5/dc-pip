// export const environment = {
//   production: false,
//   apiUrl: 'http://localhost:8080/api' 
// };


//1st deployment
export const environment = {
  production: true,
  apiUrl: '/api' ,
  enabledDebug: false
 
  
};

